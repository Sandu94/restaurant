<?php

//require configuration file
require_once('../../configuration.php');
//get languages
require_once('../../system/languages.php');
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
	<?php require('../head.php'); ?>
	<title><?php echo $lang['SITE_BASE_TITLE'] . $lang['chef_add']; ?></title>
</head>


<body class="backend row index-events menu-block-backend">
<!-- ####### HEADER for logged in users ############################################################## -->
<?php if (loggedIn()) { //if A	
	$query = mysqli_query($con, "SELECT * FROM users WHERE user_name = '" . $_SESSION['user_name'] . "' LIMIT 1") or trigger_error("Query Failed: " . mysqli_error($con));
    $query2 = mysqli_fetch_array($query);

 	// if user_role is Administrator 
 	if ($query2['user_role'] == 'Administrator' || $query2['user_role'] == 'Manager') { ?>
	<header class="row loggedin">
		<div class="">
			<div class="col-md-6">
				<span class="label label-success pull-left">
				<?php if ($query2['user_role'] == 'Administrator') { ?>
					<?php echo $lang['role']; ?><strong>Administrator</strong>
				<?php } ?>
				</span>
				<div class="pull-left">
					<a title="<?php echo $lang['back_into_the_site']; ?>" href="<?php echo $CONF['installation_path']; ?>">
						<?php echo $lang['back_into_the_site']; ?>
					</a>
				</div>
			</div>
			<div class="col-md-6"><p class="pull-right"><?php echo $lang['cp_login_hello'] . $query2['user_nice_name']; ?>! <a href="<?php echo $CONF['installation_path']; ?>backend/login.php?action=logout"><span class="label label-warning"><?php echo $lang['log_out']; ?></span></a></p></div>
		</div>
	</header>


    <div class="col-md-2 v2-sidebar-menu">
        <?php if ($query2['user_role'] == 'Administrator') { ?>
            <?php include('menu-administrators.php'); ?>
        <?php }else if ($query2['user_role'] == 'Client') {  ?>
            <?php include('menu-clients.php');  ?>
        <?php } ?>
    </div>

    <div class="col-md-10 v2-page-content">
        <div class="row">
	        <div class="col-md-12 chef-list top-area">
        		<div class="top_area_margin">
        			<h1 class="clearfix"><?php echo $lang['chefs_add']; ?></h1>

        			<form id="add_chef_form" class="chefs_add col-md-9" method="POST" enctype="multipart/form-data">
        				<div class="row">
                            <div class="col-md-12 input_holder">
                                <div class="row">
                                    <div class="titles_infos_group">
                                        <label class="col-md-4">Upload Chef's Image</label>
                                        <div class="col-md-8">
                                            <div class="relative">
                                                <input type="hidden" name="MAX_FILE_SIZE" value="4194304" />
                            					<input type="file" name="chef_image" class="file" />
                            			        <div class="fake_input_holder">
                            			            <input required type="button" value="<?php echo $lang['cp_chef_picture']; ?>" />
                                                </div>
                        			        </div>
                                        </div>
                                    </div>

                                    <div class="titles_infos_group">
                                        <label class="col-md-4">Chef Name</label>
                                        <div class="col-md-8">
                                            <input required type="text" class="form-control" name="chef_name" placeholder="Chef Name" />
                                        </div>
                                    </div>

                                    <div class="titles_infos_group">
                                        <label class="col-md-4">Password</label>
                                        <div class="col-md-8">
                                            <input required type="password" class="form-control" name="chef_password" placeholder="Password" />
                                        </div>
                                    </div>

                                    <div class="titles_infos_group">
                                        <label class="col-md-4">Contact No</label>
                                        <div class="col-md-8">
                                            <input required type="text" class="form-control" name="chef_phone" placeholder="Chef Contact No" />
                                        </div>
                                    </div>

                                    <div class="titles_infos_group">
                                        <label class="col-md-4">Expertise Area</label>
                                        <div class="col-md-8">
											<select class="form-control" name="chef_expertise_area">
												<option>Main Dishes</option>
												<option>Desserts</option>
                                                <option>Beverages</option>
                                                <option>Pizza</option>
											</select>
                                        </div>
									</div>

                                    </div>

                                    <div class="titles_infos_group">
                                        <label class="col-md-4">Birth Day</label>
                                        <div class="col-md-8">
                                            <input required type="date" class="form-control" name="chef_birthday" />
                                        </div>
                                    </div>

                                    <div class="titles_infos_group">
                                        <label class="col-md-4">Experience</label>
                                        <div class="col-md-8">
                                            <textarea required placeholder="Add chef's experience" class="form-control" name="chef_experience"></textarea>
                                        </div>
                                    </div>
                                    <input type="submit" name="submit_add" value="Add Chef" class="btn btn-success" />
            				    </div>
                            </div>
                        </div>
        			</form>
        		</div>

                <?php
                    #Adding an Event
                    if(isset($_POST["submit_add"])) {
                        // infos from form names using $_POST[];
                        $chef_name = htmlspecialchars( (string)$_POST["chef_name"] );
                        $chef_phone = htmlspecialchars( (string)$_POST["chef_phone"] );
                        $chef_expertise_area = htmlspecialchars( (string)$_POST["chef_expertise_area"] );
                        $chef_birthday = htmlspecialchars( (string)$_POST["chef_birthday"] );
                        $chef_experience = htmlspecialchars( (string)$_POST["chef_experience"] );
                        $chef_password = htmlspecialchars( (string)$_POST["chef_password"] );

                        if(isset($_FILES['chef_image'])){
                            $errors= array();
                            $file_name = $_FILES['chef_image']['name'];
                            $file_size =$_FILES['chef_image']['size']; 
                            $file_tmp =$_FILES['chef_image']['tmp_name'];
                            $file_type=$_FILES['chef_image']['type'];   

                            $file_ext = explode('.', $file_name);
                            $extension = end($file_ext);

                            $chef_image = 'skin/images/chefs/'.$file_name;

                            $expensions= array("jpeg","jpg","png","gif","bmp");         
                            if(in_array($extension,$expensions)=== false){
                                $errors[]= $lang['cp_chef_error'] . "jpeg, jpg, png, gif, bmp.";
                            }
                            if($file_size > 4194304){
                                $errors[] = $lang['cp_food_picture'];
                            }               
                            if(empty($errors)==true){
                                move_uploaded_file($file_tmp,'../../skin/images/chefs/'.$file_name);
                            }else{
                                print_r($errors);
                            }
                        }

                        #Query to insert in the database the event
                        $query_orderuser = "INSERT INTO chef (
                            chef_name,
                            chef_phone,
                            expertise_area,
                            chef_birthday,
                            chef_experience,
                            chef_image,
                            chef_password  
                        ) VALUES (
                            '$chef_name',
                            '$chef_phone',
                            '$chef_expertise_area',
                            '$chef_birthday',
                            '$chef_experience',
                            '$chef_image',
                            '$chef_password'
                            
                        );";
                        mysqli_query($con, $query_orderuser); 
                        #Success message ?>
                        <div role="alert" class="alert alert-success">
                          <?php echo $lang['cp_chef_message_added']; ?>
                        </div>
                    <?php } ?>
            </div>
        </div>
    </div>

<?php }
} else { ?>
   		<script>window.location.replace("<?php echo $CONF['installation_path'] . 'backend/'; ?>");</script>
<?php } ?>


</body>
</html>