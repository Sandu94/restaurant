<?php

//require configuration file
require_once('../../configuration.php');
//get languages
require_once('../../system/languages.php');
?>

<!DOCTYPE html>
<html lang="en-US">
<head>
	<?php require('../head.php'); ?>
	<title><?php echo $lang['SITE_BASE_TITLE'] . $lang['chef_list']; ?></title>
</head>


<body class="backend row index-events menu-block-backend">
<!-- ####### HEADER for logged in users ############################################################## -->
<?php if (loggedIn()) {
	$query = mysqli_query($con, "SELECT * FROM users WHERE user_name = '" . $_SESSION['user_name'] . "' LIMIT 1") or trigger_error("Query Failed: " . mysqli_error($con));
    $query2 = mysqli_fetch_array($query);

 	// if user_role is Administrator 
 	if ($query2['user_role'] == 'Administrator') { ?>
	<header class="row loggedin">
		<div class="">
			<div class="col-md-6">
				<span class="label label-success pull-left">
				<?php if ($query2['user_role'] == 'Administrator') { ?> 
					<?php echo $lang['role']; ?><strong>Administrator</strong>
				<?php } ?>
				</span>
				<div class="pull-left">
					<a title="<?php echo $lang['back_into_the_site']; ?>" href="<?php echo $CONF['installation_path']; ?>">
						<?php echo $lang['back_into_the_site']; ?>
					</a>
				</div>
			</div>
			<div class="col-md-6"><p class="pull-right"><?php echo $lang['cp_login_hello'] . $query2['user_nice_name']; ?>! <a href="<?php echo $CONF['installation_path']; ?>backend/login.php?action=logout"><span class="label label-warning"><?php echo $lang['log_out']; ?></span></a></p></div>
		</div>
	</header>


    <div class="col-md-2 v2-sidebar-menu">
        <?php if ($query2['user_role'] == 'Administrator') { ?>
            <?php include('menu-administrators.php'); ?>
        <?php }else if ($query2['user_role'] == 'Client') {  ?>
            <?php include('menu-clients.php');  ?>
        <?php } ?>
    </div>

    <div class="col-md-10 v2-page-content">
        <div class="row">
	        <div class="col-md-12 chef-list top-area">
                <h1 class="clearfix"><?php echo $lang['chef_list']; ?></h1>
                <?php
                    #Removing a chef
                    if(isset($_POST['remove_this_chef'])){
                        #Get chef ID
                        $remove_this_chef_id = $_POST['remove_this_chef_id'];
                        #Query to remove the Chef
                        $query_edit_menu = "DELETE FROM chef WHERE chef_id='$remove_this_chef_id'";
                        mysqli_query($con, $query_edit_menu);
                        #Success message ?>
                        <div role="alert" class="alert alert-success">
                          <?php echo $lang['cp_chef_message_deleted']; ?>
                        </div>
                    <?php }

                    #Modify an Event
                    if(isset($_POST["update_submit_chef"])){
                        $update_Chef_name = htmlspecialchars( (string)$_POST["update_Chef_name"] );
                        $update_chef_phone = htmlspecialchars( (string)$_POST["update_chef_phone"] );
                        $update_chef_expertise_area = htmlspecialchars( (string)$_POST["update_chef_expertise_area"] );
                        $update_chef_birthday = htmlspecialchars( (string)$_POST["update_chef_birthday"] );
                        $update_chef_experience = htmlspecialchars( (string)$_POST["update_chef_experience"] );
                        $update_chef_password = htmlspecialchars( (string)$_POST["update_chef_password"] );

                        $update_chef_id = $_POST['update_chef_id'];

                        if(isset($_FILES['update_chef_image']) && $_FILES['update_chef_image']['name']){
                            $errors= array();
                            $file_name = $_FILES['update_chef_image']['name'];
                            $file_size =$_FILES['update_chef_image']['size'];
                            $file_tmp =$_FILES['update_chef_image']['tmp_name'];
                            $file_type=$_FILES['update_chef_image']['type'];   

                            $file_ext = explode('.', $file_name);
                            $extension = end($file_ext);

                            $chef_image = 'skin/images/chefs/'.$file_name;

                            $expensions= array("jpeg","jpg","png","gif","bmp");         
                            if(in_array($extension,$expensions)=== false){
                                $errors[]= $lang['cp_chef_error'] . "jpeg, jpg, png, gif, bmp.";
                            }
                            if($file_size > 4194304){
                                $errors[] = $lang['cp_food_picture'];
                            }               
                            if(empty($errors)==true){
                                move_uploaded_file($file_tmp,'../../skin/images/chefs/'.$file_name);
                            }else{
                                print_r($errors);
                            }
                            #Query to edit chef
                            $query_edit_menu = "UPDATE chef SET 
                            chef_image='$chef_image', 
                            Chef_name='$update_Chef_name', 
                            chef_phone='$update_chef_phone', 
                            expertise_area='$update_chef_expertise_area', 
                            chef_birthday='$update_chef_birthday', 
                            chef_experience ='$update_chef_experience',
                            chef_password = '$update_chef_password',
                            chef_image = '$chef_image'
                            WHERE chef_id='$update_chef_id'";
                            mysqli_query($con, $query_edit_menu);

                        }else{
                            #Query to edit chef
                            $query_edit_menu = "UPDATE chef SET 
                            chef_image='$chef_image', 
                            Chef_name='$update_Chef_name', 
                            chef_phone='$update_chef_phone', 
                            expertise_area='$update_chef_expertise_area', 
                            chef_birthday='$update_chef_birthday', 
                            chef_experience ='$update_chef_experience',
                            chef_password = '$update_chef_password',
                            chef_image = '$chef_image'
                            WHERE chef_id='$update_chef_id'";
                            mysqli_query($con, $query_edit_menu);
                        }

                        #Success message ?>
                        <div role="alert" class="alert alert-success">
                          <?php echo $lang['cp_chef_message_modified']; ?>
                        </div>
                    <?php }
                ?>
        	</div>
        	<div class="row bottom_area_margin">
        		<div class="container">
        		<?php $query_chef = mysqli_query($con, "SELECT * FROM chef") or trigger_error("Query Failed: " . mysqli_error($con));
        		?>
        		<ul class="chef_list row">
        			<?php while($query_chef = mysqli_fetch_array($query_chef)) { 
        				?>
        			<li class="single_chef col-md-10">
                        <div class="col-md-2">
						    <img src="<?php echo '../../system/timthumb.php?src=' . $CONF['installation_path'] . $query_chef['chef_image'] . '&amp;h=250&amp;w=250&amp;zc=1'; ?>" alt="<?php echo $query_chef['chef_name']; ?>" />
                        </div>
                        <div class="col-md-10">
                            <h4>
                                <strong><?php echo $query_chef['chef_name']; ?></strong>
                                - <?php echo $query_chef['expertise_area']; ?> <strong>
                            </h4>
                            <p><?php echo $query_chef['chef_experience']; ?></p>
                            <div class="actions">
                                
                                <!-- Edit chef-->
                                <?php include 'testimonials-modal.php'; ?>
                                <button data-toggle="modal" data-target="#modal_<?php echo $query_chef['chef_id']; ?>" class="edit_row edit_testimonial phpr_edit_event_modal btn btn-info btn-xs pull-left md-trigger"><i class="fa fa-pencil-square-o"></i> Edit</button>

                                <!-- Remove chef -->
                                <form method="POST" class="mgf_remove_event">
                                    <input type="hidden" name="remove_this_chef_id" value="<?php echo $query_chef['chef_id']; ?>">
                                    <button onclick="return confirm(<?php echo $lang['cp_event_are_you_sure']; ?>)" name="remove_this_chef" type="submit" class="phpr_delete_event_modal btn btn-danger btn-xs pull-left"><i class="fa fa-times"></i>Delete</button>
                                </form>
                            </div>
                        </div>
        			</li>
        			<?php } ?>
        		</ul>
        		</div>
        	</div>



<?php }
} else { ?>
   		<script>window.location.replace("<?php echo $CONF['installation_path'] . 'backend/'; ?>");</script>
<?php } ?>


</body>
</html>