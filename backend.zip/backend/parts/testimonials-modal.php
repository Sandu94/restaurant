<div class="modal fade" id="modal_<?php echo $query_chef['chef_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="modal_<?php echo $query_chef['testimonial_id']; ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">
                    <?php echo $lang['cp_table_update'] . $query_chef['chef_name']; ?>
                    <?php echo ' (ID: ' .$query_chef['chef_id'] . ')'; ?>
                </h4>
            </div>
            <div class="modal-body">
                <form method="POST" enctype="multipart/form-data" class="row">
                    <!-- ID -->
                    <input type="hidden" name="update_chef_id" value="<?php echo $query_chef['chef_id']; ?>" />
                    <input type="hidden" name="MAX_FILE_SIZE" value="4194304" />
                    <!-- Name -->
                    <div class="row margin_bottom_10">
                        <label class="row">Chef Name</label>
                        <div class="row">
                            <input type="text" class="form-control" name="update_chef_name" value="<?php echo $query_chef['chef_name']; ?>" />
                        </div>
                    </div> 
                    <!-- PHONE -->
                    <div class="row margin_bottom_10">
                        <label class="row">Chef Contact No</label>
                        <div class="row">
                            <input type="text" class="form-control" name="update_chef_phone" value="<?php echo $query_chef['chef_phone']; ?>" />
                        </div>
                    </div> 
                    <!-- Works at -->
                    <div class="row margin_bottom_10">
                        <label class="row">Chef Birthday</label>
                        <div class="row">
                            <input type="text" class="form-control" name="update_chef_birthday" value="<?php echo $query_chef['chef_birthday']; ?>" />
                        </div>
                    </div> 
                    <!-- Experience -->
                    <div class="row margin_bottom_10">
                        <label class="row">Experience</label>
                        <div class="row">
                            <textarea class="form-control" name="update_chef_experience"><?php echo $query_chef['update_chef_experience']; ?></textarea>
                        </div>
                    </div>
                    <!-- Image -->
                    <div class="row margin_bottom_10">
                        <label class="row"><?php echo $lang['change_image']; ?></label>
                        <div class="row">
                            <div class="inputs_holder">
                                <input class="form-control" type="file" name="update_chef_image" value="<?php echo $query_chef['update_chef_image']; ?>" />
                                <div class="fake_input_holder">
                                    <input type="button" value="<?php echo $lang['cp_food_picture']; ?>">
                                </div>
                            </div>
                        </div>
                    </div>  
                    <!-- Submit button -->
                    <div class="row">
                        <div class="row">
                            <input type="submit" class="btn btn-success form-control" value="<?php echo $lang['update']; ?>" name="update_submit_chef" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>